CANON SOFTWARE LICENSE AGREEMENT

IMPORTANT!

This is a legal agreement ("Agreement") between you and Canon Inc. 
("Canon") and governing your use of Canon's software programs 
including the related manuals or any printed material thereof  
(the "Software") for certain Canon's copying machines, printers and 
multifunctional peripherals (the "Products").

READ CAREFULLY AND UNDERSTAND ALL OF THE RIGHTS AND RESTRICTIONS 
DESCRIBED IN THIS AGREEMENT BEFORE USING THE SOFTWARE. BY THE ACTION 
TO INDICATE YOUR ACCEPTANCE OR USING THE SOFTWARE, YOU AGREE TO BE 
BOUND BY THE TERMS AND CONDITIONS OF THIS AGREEMENT. IF YOU DO NOT 
AGREE TO THE FOLLOWING TERMS AND CONDITIONS OF THIS AGREEMENT, DO 
NOT USE THE SOFTWARE. NO REFUND WILL BE MADE BECAUSE THE SOFTWARE 
WAS PROVIDED TO YOU AT NO CHARGE.


1.  GRANT OF LICENSE
Canon grants you a personal, limited and non-exclusive license to 
use ("use" as used herein shall include storing, loading, 
installing, accessing, executing or displaying) the Software solely 
for the use with Products only on computers directly or via network 
connected to the Products (the "Designated Computer").
You may allow other users of other computers connected to your 
Designated Computer to use the Software, provided that you must 
assure that all such users shall abide by the terms of this 
Agreement and shall be subject to restrictions and obligations borne 
by you hereunder.

You may make one copy of the Software solely for a back-up purpose.

2.  RESTRICTIONS
You shall not use the Software except as expressly granted or 
permitted herein, and shall not assign, sublicense, sell, rent, 
lease, loan, convey or transfer to any third party the Software.
You shall not alter, translate or convert to another programming 
language, modify, disassemble, decompile or otherwise reverse 
engineer the Software and you shall not have any third party to do 
so.

3.  COPYRIGHT NOTICE
You shall not modify, remove or delete any copyright notice of Canon 
or its licensors contained in the Software, including any copy 
thereof.

4.  OWNERSHIP
Canon and its licensors retain in all respects the title, ownership 
and intellectual property rights in and to the Software.  Except as 
expressly provided herein, no license or right, express or implied, 
is hereby conveyed or granted by Canon to you for any intellectual 
property of Canon and its licensors.

5.  EXPORT RESTRICTION
You agree to comply with all export laws and restrictions and 
regulations of the country involved, and not to export or re-export, 
directly or indirectly, the Software in violation of any such laws, 
restrictions and regulations, or without all necessary approvals.

6.  NO SUPPORT
NEITHER CANON, CANON'S SUBSIDIARIES OR AFFILIATES, THEIR 
DISTRIBUTORS, OR DEALERS NOR CANON'S LICENSORS ARE RESPONSIBLE FOR 
MAINTAINING OR HELPING YOU TO USE THE SOFTWARE. NO UPDATES, FIXES OR 
SUPPORTS WILL BE MADE AVAILABLE FOR THE SOFTWARE.

7.  NO WARRANTY AND DISCLAIMER OF INDEMNITY
[NO WARRANTY]  THE SOFTWARE IS PROVIDED "AS IS" WITHOUT WARRANTY OF 
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO 
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE ENTIRE RISK AS TO THE QUALITY AND 
PERFORMANCE OF THE SOFTWARE IS WITH YOU. SHOULD THE SOFTWARE PROVE 
DEFECTIVE, YOU ASSUME THE ENTIRE COST OF ALL NECESSARY SERVICING, 
REPAIR OR CORRECTION. SOME STATES OR LEGAL JURISDICTIONS DO NOT 
ALLOW THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSION 
MAY NOT APPLY TO YOU. THIS WARRANTY GIVES YOU SPECIFIC LEGAL RIGHTS 
AND YOU MAY ALSO HAVE OTHER RIGHTS WHICH VARY FROM STATE TO STATE OR 
JURISDICTION TO JURISDICTION.

NEITHER CANON, CANON'S SUBSIDIARIES OR AFFILIATES, THEIR 
DISTRIBUTORS, OR DEALERS NOR CANON'S LICENSORS WARRANT THAT THE 
FUNCTIONS CONTAINED IN THE SOFTWARE WILL MEET YOUR REQUIREMENTS OR 
THAT THE OPERATION OF THE SOFTWARE WILL BE UNINTERRUPTED OR ERROR 
FREE.

[NO LIABILITY FOR DAMAGES] IN NO EVENT SHALL EITHER CANON, CANON'S 
SUBSIDIARIES OR AFFILIATES, THEIR DISTRIBUTORS DEALERS OR CANON'S 
LICENSORS BE LIABLE FOR ANY DAMAGES WHATSOEVER (INCLUDING WITHOUT 
LIMITATION, LOSS OF BUSINESS PROFITS, LOSS OF BUSINESS INFORMATION, 
LOSS OF BUSINESS INTERRUPTION OR OTHER COMPENSATORY, INCIDENTAL OR 
CONSEQUENTIAL DAMAGES) ARISING OUT OF THE SOFTWARE, USE THEREOF OR 
INABILITY TO USE THE SOFTWARE EVEN IF EITHER CANON, CANON'S 
SUBSIDIARIES OR AFFILIATES, THEIR DISTRIBUTORS, DEALERS OR CANON'S 
LICENSORS HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. SOME 
STATES OR LEGAL JURISDICTIONS DO NOT ALLOW THE LIMITATION OR 
EXCLUSION OF LIABILITY FOR INCIDENTAL OR CONSEQUENTIAL DAMAGES, OR 
PERSONAL INJURY OR DEATH RESULTING FROM NEGLIGENCE ON THE PART OF 
SELLER, SO THE ABOVE LIMITATION OR EXCLUSION MAY NOT APPLY TO YOU.

[RELEASE OF LIABILITY] TO THE FULL EXTENT PERMITTED BY APPLICABLE 
LAW, YOU HEREBY RELEASE CANON, CANON'S SUBSIDIARIES AND AFFILIATES, 
THEIR DISTRIBUTORS, DEALERS AND CANON'S LICENSORS FROM ANY AND ALL 
LIABILITY ARISING FROM OR RELATED TO ALL CLAIMS CONCERNING THE 
SOFTWARE OR ITS USE.

8.  TERM
This Agreement is effective upon your acceptance hereof by the 
action to indicate your acceptance or using the Software and remains 
in effect until terminated. You may terminate this Agreement by 
destroying the Software including any and all copies thereof. This 
Agreement shall also terminate if you fail to comply with any terms 
hereof. Upon termination of this Agreement, in addition to Canon 
enforcing its respective legal rights, you must then promptly 
destroy the Software including any and all copies thereof.
Notwithstanding the foregoing, Sections 4, and 7 through 11 shall 
survive any termination of this Agreement.

9.  U.S. GOVERNMENT RESTRICTED RIGHTS NOTICE
The Software is a "commercial item," as that term is defined at 
48 C.F.R. 2.101 (October 1995), consisting of "commercial computer 
software" and "commercial computer software documentation," as such 
terms are used in 48 C.F.R. 12.212 (September 1995). Consistent with 
48 C.F.R. 12.212 and 48 C.F.R. 227.7202-1 through 227.7202-4 
(June 1995), all U.S. Government End Users shall acquire the 
Software with only those rights set forth herein. Manufacturer is 
Canon Inc./30-2, Shimomaruko 3-chome, Ohta-ku, Tokyo 146-8501, Japan.

10.  SEVERABILITY
In the event that any section hereof is declared or found to be 
illegal by any court or tribunal of competent jurisdiction, such 
section shall be null and void with respect to the jurisdiction of 
that court or tribunal and all the remaining provisions hereof shall 
remain in full force and effect.

11.  ACKNOWLEDGEMENT
BY THE ACTION TO INDICATE YOUR ACCEPTANCE OR USING THE SOFTWARE, YOU 
ACKNOWLEDGE THAT YOU HAVE READ THIS AGREEMENT, UNDERSTOOD IT, AND 
AGREE TO BE BOUND BY ITS TERMS AND CONDITIONS. YOU ALSO AGREE THAT 
THIS AGREEMENT IS THE COMPLETE AND EXCLUSIVE STATEMENT OF AGREEMENT 
BETWEEN YOU AND CANON CONCERNING THE SUBJECT MATTER HEREOF AND 
SUPERSEDES ALL PROPOSALS OR PRIOR AGREEMENTS, VERBAL OR WRITTEN, AND 
ANY OTHER COMMUNICATIONS BETWEEN YOU AND CANON RELATING TO THE 
SUBJECT MATTER HEREOF. NO AMENDMENT TO THIS AGREEMENT SHALL BE 
EFFECTIVE UNLESS SIGNED BY A DULY AUTHORISED REPRESENTATIVE OF CANON.


Should you have any questions concerning this Agreement, or if you 
desire to contact Canon for any reason, please write to Canon's 
sales subsidiary or distributor/dealer, serving the country where 
you obtained the Products.

Canon Inc.


Supplement

====================================================================

Copyright 2007 Canon, Inc.

Windows XP/Server 2003/Vista x64 Edition 
                           Canon CARPS Printer/Fax/Scanner Driver 
                                                        Version 3.00

====================================================================

Trademarks and Notices
o Canon is a trademark of Canon Inc.
o Microsoft, Windows and Windows Server are registered trademarks of
  Microsoft Corporation in the United States and other countries.
  Windows Vista is a trademark of Microsoft Corporation in the
  United States and other countries.
o In this document:
  Microsoft(R) Windows(R) XP Professional x64 Edition is referred
  to as "Windows XP." Microsoft(R) Windows Server(R) 2003 x64
  Edition is referred to as "Windows Server 2003."  Microsoft(R)
  Windows Vista(TM) x64 Edition is referred to as "Windows Vista."
o All other product and brand names are registered trademarks,
  trademarks or service marks of their respective owners.



CONTENTS
========
General Notes
1. Introduction
2. System Requirements
3. Installing and Uninstalling the Drivers

Application Notes
1. Printing
 1.1. Print Job Settings
 1.2. Cautions, Limitations, and Restrictions
2. Faxing
 2.1. Cautions, Limitations, and Restrictions
Customer Service


General Notes
=============

1. Introduction

Thank you for choosing the CARPS Printer/Fax/Scanner Driver for 
Microsoft Windows. The CARPS Printer/Fax/Scanner Driver lets you
print, fax, and scan from your computer.


2. System Requirements

The CARPS Printer/Fax/Scanner Driver can be installed and used
in the following system environments: 

  - Operating System Software
    Microsoft Windows XP Professional x64 Edition
    Microsoft Windows Sever 2003, Enterprise x64 Edition
                               (Network connection Only)
    Microsoft Windows Sever 2003, Standard x64 Edition
                               (Network connection Only)
    Microsoft Windows Vista x64 Edition

  - Computer
    Any computer that can run the operating system software 
    listed above.

Notes:
 o The CARPS Printer Driver cannot be used with the machine of any 
   operating system other than the ones described above.
 o Some USB hubs may experience problems with CARPS Printer Driver.
   If this happens, connect the machine directly to the USB port on 
   your computer, or change the USB port that the machine is 
   connected to.
 o Certain personal computers (including laptops) may not restart 
   correctly from standby mode when the printer is attached. If this 
   occurs, please restart your computer.


3. Installing and Uninstalling the Drivers
To print, fax, and scan from software applications that operate on
Windows XP/Server 2003/Vista x64 Edition, follow the procedures
below to install the CARPS printer/fax/scanner drivers.
(The scanner driver is for Windows XP/Vista Only.)

Before you install the software, be sure to:
 o Confirm the machine is not connected to your computer.
 o Turn on the machine.
 o Quit any Windows application running on your computer.

Important:
 o Installation needs to be done by a user with administrator 
   privileges.

Note:
 o Use of a USB cable 3 m long or less is recommended.


Installing the Drivers on Windows Vista

 * If the [User Account Control] dialog box appears while
   installing the drivers, verify that the proposed action is what
   you requested, and then click [continue].

 To Install the Printer/Fax/Scanner Drivers Using a USB Connection:
   1. Connect the machine to your computer using a USB cable.
   2. When the [Found New Hardware] dialog box appears, click 
      [Locate and install driver software (recommended)].
   3. On the [Allow Windows to search online for driver software for
      your <name of printer>?] screen, click [Don't search online].
   4. On the [Insert the disc that came with your <name of printer>]
      screen, click [I don't have the disc. Show me other options.]
   5. On the [Windows couldn't find driver software for your device]
      screen, click [Browse my computer for driver software
      (advanced)].
   6. On the [Browse for driver software on your computer] screen,
      click [Browse] to specify where you saved the 
      [x64\DRIVERS\<name of language>] folder, and then click [Next].
   7. Installation will begin. When the [The software for this
      device has been successfully installed] screen appears, click
      [Close].
   8. If the [Allow Windows to search online for driver software for
      your <name of printer>?] screen reappears, repeat steps 3
      through 7.

   When the [Found New Hardware] dialog box stops reappearing,
   installations of the drivers are complete.

 To Install the Printer Driver Using a Network Connection:
   1. Connect the machine to the network.
   2. From the computers [Start] menu, click [Control Panel], click
      [Hardware and Sound], and then click [Printer].
   3. In the [Printers] folder, click [Add a printer].
   4. When the [Add printer] dialog box appears, click [Add a local
      printer].
   5. On the [Choose a printer port] screen, click [Create a new
      port], select [Standard TCP/IP Port], and then click [Next].
   6. On the [Type a printer hostname or IP address] screen, enter
      the IP address that you have set to the printer into the
      [Hostname or IP address] field, and then click [Next].
   7. On the [Install the printer driver] screen, click [Have Disk].
   8. When the [Install From Disk] dialog box appears, click [Browse]
      and specify where you have saved the 
      [\x64\DRIVERS\<name of language>] folder, and then click [OK].
   9. On the [Install the printer driver] screen, select the printer
      driver from [Printers], and then click [Next].
   10. On the [Type a printer name] screen, click [Next].
       - If you want to change the name of the printer, enter a new
         name into the [Printer name] field.
       - If you want to use this printer as the default printer,
         select [Set as the default printer].
   11. When [You�fve successfully added <name of printer>] screen
       appears, click [Finish].

   Installation of the driver is complete.

 To Install the Fax Driver Using a Network Connection:
   1. Connect the machine to the network.
   2. From the computers [Start] menu, click [Control Panel], click
      [Hardware and Sound], and then click [Printer].
   3. In the [Printers] folder, click [Add a printer].
   4. When the [Add printer] dialog box appears, click [Add a local
      printer].
   5. On the [Choose a printer port] screen, choose one of the
      following procedures:
      - If the CARPS printer driver for the network connection is
        already installed, click [Use an existing port] to
        select the port that you created in step 5 of the network
        printer installation, and then click [Next] to proceed to
        step 7.
      - If the CARPS printer driver for the network connection is
        not installed, click [Create a new port], select [Standard 
        TCP/IP Port], and then click [Next].
   6. On the [Type a printer hostname or IP address] screen, enter
      the IP address that you have set to the machine into the
      [Hostname or IP address] field, and then click [Next].
   7. On the [Install the printer driver] screen, click [Have Disk].
   8. When the [Install From Disk] dialog box appears, click [Browse]
      and specify where you have saved the 
      [\x64\DRIVERS\<name of language>] folder, and then click [OK].
   9. On the [Install the printer driver] screen, select the fax
      driver from [Printers], and then click [Next].
   10. On the [Type a printer name] screen, click [Next].
       - If you want to change the name of the fax, enter a new name
         into the [Printer name] field.
       - If you want to use this fax as the default printer, select
         [Set as the default printer].
   11. When the [You�fve successfully added <name of printer>]
       screen appears, click [Finish].

   Installation of the driver is complete.

Uninstalling the drivers on Windows Vista

 To Uninstall the Scanner Driver:
   1. From the computers [Start] menu, click [Control Panel], click
      [Hardware and Sound], and then click [Device Manager].
   2. In the [Imaging Devices], select the printer you want to
      uninstall, click the [Action] menu, and then click [properties].
   3. On the [<name of scanner> Properties] dialog box, click the
      [Driver] tab, and then click [Uninstall].
   4. If you also want to delete the driver from the DriverStore,
      select [Delete the driver software for the device.] in the
      [Confirm Device Uninstall] dialog box, and then click [OK].

   Uninstallation of the driver is complete.

 To Uninstall the Printer/Fax Driver:
   * The procedure below is for uninstalling the printer driver. To
    uninstall the fax driver, select the fax you want to uninstall
    in step 2.
   1. From the computers [Start] menu, click [Control Panel], click
      [Hardware and Sound], and then click [Printer].
   2. In the [Printer] folder, select the printer you want to 
      uninstall, click the [File] menu, and then click [Delete].
   3. On the [Are you sure you want to delete the printer '<name of
      printer>'?] dialog box, click [Yes].
   4. In the [File] menu, select [Run as administrator], and then
      click [Server Properties].
   5. On the [Printer Server Properties] dialog box, click the
      [Driver] tab, select the printer you want to uninstall, and
      then click [Remove].
   6. If you also want to remove the driver from the DriverStore,
      select [Remove driver and driver package.] on the [Remove
      Driver And Package] dialog box, and then click [OK].
   7. Verify that the printer being uninstalled is the one you
      specified, and then click [Yes].

   Uninstallation of the driver is complete.

Installing the Drivers on Windows XP/Server 2003

 To Install the Printer/Fax/Scanner Drivers Using a USB Connection
                                                 (Windows XP Only):
   1. Connect the machine to your computer using a USB cable.
   2. When the [Found New Hardware Wizard] appears, click [No, not
      this time], and then click [Next].
   3. Select [Install from a list or specific location (Advanced)]
      and then click [Next].
   4. On the [Please choose your search and installation options.]
      screen, click [Include this location in the search.], click
      [Browse] to specify where you saved the 
      [x64\DRIVERS\<name of language>] folder, and then click [Next].
   5. When the [Completing the Found New Hardware Wizard] screen 
      appears, click [Finish].
   6. If the [Found New Hardware Wizard] reappears, repeat steps 2
      through 5.

   When the [Found New Hardware Wizard] stops reappearing,
   installations of the drivers are complete.

 To Install the Printer Driver Using a Network Connection:
   1. Connect the machine to the network.
   2. From the computers [Start] menu, click [Printers and Faxes],
      and then click [Add a printer].
   3. When the [Add Printer Wizard] appears, click [Next].
   4. On the [Local or Network Printer] screen, remove the check
      mark from [Automatically detect and install my Plug and Play
      printer], and then click [Next].
   5. On the [Select a Printer Port] screen, click [Create a new
      port], select [Standard TCP/IP Port], and then click [Next].
   6. When the [Add Standard TCP/IP Printer Port Wizard] appears,
      click [Next].
   7. On the [Add Port] screen, enter the IP address that you have
      set to the printer into the [Printer Name or IP Address] field,
      and then click [Next].
   8. On the [Completing the Add Standard TCP/IP Printer Port Wizard]
      screen, click [Finish].
   9. On the [Install Printer Software] screen, click [Have Disk].
   10. When the [Install From Disk] dialog box appears, click
       [Browse] and specify where you have saved the
       [\x64\DRIVERS\<name of language>] folder, and then click [OK].
   11. On the [Install Printer Software] screen, select the printer
       driver from [Printers], and then click [Next].
   12. On the [Name Your Printer] screen, click [Next].
       - If you want to change the name of the printer, enter a new
         name into the [Printer name] field.
   13. On the [Printer Sharing] screen, click [Next].
       - Printer sharing is optional.
   14. On the [Print Test Page] screen, click [Next].
       - Printing of a test page is optional.
   15. When the [Completing the Add Printer Wizard] screen appears,
       click [Finish].

   Installation of the driver is complete.

 To Install the Fax Driver Using a Network Connection:
   1. Connect the machine to the network. 
   2. From the computers [Start] menu, click [Printers and Faxes],
      and then click [Add a printer].
   3. When the [Add Printer Wizard] appears, click [Next].
   4. On the [Local or Network Printer] screen, remove the check
      mark from [Automatically detect and install my Plug and Play
      printer], and then click [Next].
   5. On the [Select a Printer Port] screen, choose one of the
      following procedures:
      - If the CARPS printer driver for the network connection is
        already installed, click [Use the following port] to select
        the port that you created in step 5 of the network printer
        installation, and then click [Next] to proceed to step 9.
      - If the CARPS printer driver for the network connection is
        not installed, click [Create a new port], select [Standard
        TCP/IP Port], and then click [Next].
   6. When the [Add Standard TCP/IP Printer Port Wizard] appears,
      click [Next].
   7. On the [Add Port] screen, enter the IP address that you have
      set to the printer into the [Printer Name or IP Address] field,
      and then click [Next].
   8. On the [Completing the Add Standard TCP/IP Printer Port Wizard]
      screen, click [Finish].
   9. On the [Install Printer Software] screen, click [Have Disk].
   10. When the [Install From Disk] dialog box appears, click
       [Browse] and specify where you have saved the
       [\x64\DRIVERS\<name of language>] folder, and then click [OK].
   11. On the [Install Printer Software] screen, select the fax
       driver from [Printers], and then click [Next].
   12. On the [Name Your Printer] screen, click [Next].
       - If you want to change the name of the fax, enter a new name
         into the [Printer name] field.
   13. On the [Printer Sharing] screen, click [Next].
       - Printer sharing is optional.
   14. On the [Print Test Page] screen, click [Next].
       - Printing of a test page is optional.
   15. When the [Completing the Add Printer Wizard] screen appears,
       click [Finish].

   Installation of the driver is complete.

Uninstalling Drivers on Windows XP/Server 2003

 To Uninstall the Scanner Driver (Windows XP Only): 
   1. From the computers [Start] menu, click [Control Panel], and
      then click [Printers and Other Hardware].
   2. In the [Printers and Other Hardware] folder, click [Scanners
      and Cameras].
   3. In the [Scanners and Cameras] folder, select the scanner you
      want to uninstall, click the [File] menu, and then click
      [Delete].
   4. When the [Confirm Device Removal] dialog box appears, verify
      that the scanner being uninstalled is the one you specified,
      and then click [Yes].

   Uninstallation of the driver is complete.

 To Uninstall the Printer/Fax Drivers:
   * The procedure below is for uninstalling the printer driver. To
     uninstall the fax driver, select the fax you want to uninstall
     in step 2.
   1. From the computers [Start] menu, click [Printers and Faxes].
   2. In the [Printers and Faxes] folder, select the printer driver
      that you want to uninstall, click the [File] menu, and then
      click [Delete].
   3. Verify that the printer being uninstalled is the one you
      specified, and then click [Yes].
   4. In the [File] menu, click [Server Properties].
   5. On the [Printer Server Properties] dialog box, click the
      [Drivers] tab, select the printer driver that you want to
      uninstall, and then click [Remove].
   6. Verify that the printer being uninstalled is the one you
      specified, and then click [Yes].

   Uninstallation of the driver is complete.


Application Notes
=================

1. Printing

 1.1. Print Job Settings

 The CARPS Printer Driver provides you to set various printer 
 settings. Refer to the following procedures when performing printer
 settings.

 To Perform Printer Settings From the Printers Window:
 You can change the printer settings from the Printers window.
 The settings you changed will remain until you change them again.

   1. Windows XP/Server 2003: click [Start] then click [Printers and
      Faxes] (Windows Vista: click [Start] and click [Control Panel]
      then click [Printers].)
   2. Right-click the printer icon and select [Properties] from the
      pop-up menu.
   3. Change the printer settings as you like.
   4. When you are finished, click [OK].

 To Perform Printer Settings From the Software Application:
 The settings using the following procedure are valid until the 
 software application is closed.

   1. In the software application, start the print job. (For example,
      select [Print] from the [File] menu.)
   2. In the Print dialog box, select the name of the printer to use,
      then click [Properties].
   3. Change the printer settings as you like.
   4. When you are finished, click [OK].


 Displaying the On-line Help

 Refer to the Help file for details on how to perform the settings.
 When you click [Help], information about the printer driver appears.


 1.2. Cautions, Limitations, and Restrictions

 Note the following limitations when using the driver or printing 
 a document.

 o For some computers, when a print job is cancelled, the next print 
   job may not be performed correctly because a reset printer signal 
   is not sent from the computer. After canceling a print job, 
   always reset the printer before starting the next print job.

 o When you print with a watermark, a part of the document where the 
   image and the watermark are overlapped may not be printed 
   clearly. If you set "Print Style" to "Transparent," you should 
   set a dark color for the "Color."

 o If the printing takes long time to process, printing may not be 
   performed normally. In that case, set the ERROR TIME OUT settings 
   in the Menu to OFF, and try the print job again.

 o When you print a document whose resolution is 1200 dpi or more, 
   it may not be printed correctly. In this case, print the document 
   at lower resolutions.

 o When an "@" character is used in the name of the printer, the 
   printer will become unrecognizable by the operating system
   because of an invalid printer name thus disabling printing,
   operation and setup.

 o When you log on to an Administrator account that is different
   from the one used to install the software, you will not be able
   to access the driver properties with Administrator privileges.
   To access the driver properties, select [Run as Administrator].

 o Specifying the Custom Paper Size 
   An administrator privilege is necessary when editing the "Custom 
   Paper Size" in the "Page Setup" tab of the printer drivers
   printing preferences dialog box.

 o In certain applications, thickness of a line can be set to a
   value smaller than 1pt but the actual thickness in the printout
   may be equivalent to that of an 1pt line.

2. Faxing

 Displaying the On-line Help

 Refer to the Help file for details on how to perform the settings.
 When you click "Help," information about the printer driver appears.

 2.1 Cautions, Limitations and Restrictions

 o Custom paper sizes are not available for sending a fax.

 o Do not specify more than 1 for the Copies option in the
   application since the fax may be sent more than once in some
   applications when the Copies option is specified in the
   application.

 o If double quotation marks or CSV separators are included in any
   of the items (Such as name and fax numbers) stored in a CSV file,
   the addresses stored in the file may not be imported to the
   address book correctly.

 o If you have upgraded your operating system from Windows 
   XP/Server 2003 to Windows Vista x64 Edition, you will no longer
   be able to access the address book.
   If this is the case, perform the following procedure.

   1. Copy the address book files (gpfax.adr and gpfax.idx) from the
      system folder (the default system folder is "C:\Windows") to
      another folder (e.g. "My Documents"). This step can be carried
      out before or after you upgrade the system.

   2. After you have upgraded the system, reinstall the fax driver
      in the new system, open the [Edit Address Book] sheet, click
      the [Specify a folder] button, and choose the folder you
      copied the address book files to in step 1 (e.g. "My Documents")
      as the address book folder.

   3. Click the [Yes] button in the following dialog box.

 o If double quotation marks are included in any of the items (Such 
   as names and fax numbers) stored in an ABK file (*.abk), the
   addresses stored in the file may not be imported to the address
   book correctly.

 o When an "@" character is used in the name of the printer, the
   printer will become unrecognizable by the operating system
   because of an invalid printer name thus disabling printing,
   operation and setup.

 o When you log on to an Administrator account that is different
   from the one used to install the software, you will not be able
   to access the driver properties with Administrator privileges. To
   access the driver properties, select [Run as Administrator].

 o In certain applications, thickness of a line can be set to a
   value smaller than 1pt but the actual thickness in the printout 
   may be equivalent to that of an 1pt line.


Customer Service
================
If you have questions about how to use the software, or if any 
points are not clear, refer to the contact list in the operating 
instructions and contact the service center nearest you.


END OF README.TXT
